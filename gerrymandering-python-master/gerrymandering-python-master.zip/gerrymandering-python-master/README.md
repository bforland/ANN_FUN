Assignment 3: Gerrymandering
============================
