from player import Player
from player import Max
from player import Min
